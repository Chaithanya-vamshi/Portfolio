/* ==========================================================================
   PREMIUM PORTFOLIO INTERACTION ENGINE (ES6+)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    // --- 1. THEME SWITCHING SYSTEM ---
    const themeToggleBtn = document.getElementById('theme-toggle');
    const body = document.body;
    
    // Check local storage for persistent user theme setting
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
    } else {
        body.classList.add('dark-theme');
        body.classList.remove('light-theme');
    }

    themeToggleBtn.addEventListener('click', () => {
        if (body.classList.contains('dark-theme')) {
            body.classList.remove('dark-theme');
            body.classList.add('light-theme');
            localStorage.setItem('theme', 'light');
        } else {
            body.classList.remove('light-theme');
            body.classList.add('dark-theme');
            localStorage.setItem('theme', 'dark');
        }
    });

    // --- 2. DYNAMIC MOBILE NAVIGATION DRAWER ---
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileNavDrawer = document.querySelector('.mobile-nav-drawer');
    const mobileCloseBtn = document.querySelector('.close-btn');
    const mobileLinks = document.querySelectorAll('.mobile-link');

    mobileMenuBtn.addEventListener('click', () => {
        mobileNavDrawer.classList.add('open');
    });

    const closeMobileMenu = () => {
        mobileNavDrawer.classList.remove('open');
    };

    mobileCloseBtn.addEventListener('click', closeMobileMenu);
    
    mobileLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    // --- 3. DYNAMIC STICKY NAVBAR & BACK-TO-TOP BUTTON ---
    const navbar = document.querySelector('.navbar');
    const backToTopBtn = document.getElementById('back-to-top');

    window.addEventListener('scroll', () => {
        const scrollPos = window.scrollY;
        
        // Sticky Navbar shrink
        if (scrollPos > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Back-to-Top fade trigger
        if (scrollPos > 400) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    });

    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // --- 4. TYPING EFFECTS ENGINE (HERO) ---
    const typingElement = document.getElementById('typing-text');
    const phrases = [
        "Full-Stack Software Developer.",
        "Web Application Engineer.",
        "Frontend & UI/UX Developer."
    ];
    let phraseIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    let typingSpeed = 70;

    const runTypingEngine = () => {
        const currentPhrase = phrases[phraseIndex];
        
        if (isDeleting) {
            typingElement.textContent = currentPhrase.substring(0, charIndex - 1);
            charIndex--;
            typingSpeed = 30; // Faster backspacing
        } else {
            typingElement.textContent = currentPhrase.substring(0, charIndex + 1);
            charIndex++;
            typingSpeed = 70; // Normal typing speed
        }

        if (!isDeleting && charIndex === currentPhrase.length) {
            isDeleting = true;
            typingSpeed = 1500; // Pause at end of phrase
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            phraseIndex = (phraseIndex + 1) % phrases.length;
            typingSpeed = 500; // Pause before typing next phrase
        }

        setTimeout(runTypingEngine, typingSpeed);
    };

    if (typingElement) {
        runTypingEngine();
    }

    // --- 5. INTERSECTION OBSERVER FOR SCROLL REVEAL & NAV LINKS ---
    const revealElements = document.querySelectorAll('.reveal-on-scroll');
    const navSections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                // Optional: stop unobserving if we only want animate once
                // revealObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.15,
        rootMargin: "0px 0px -50px 0px"
    });

    revealElements.forEach(el => revealObserver.observe(el));

    // Nav Section Highlighter
    window.addEventListener('scroll', () => {
        let currentSectionId = '';
        
        navSections.forEach(section => {
            const sectionTop = section.offsetTop - 120;
            const sectionHeight = section.clientHeight;
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSectionId = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSectionId}`) {
                link.classList.add('active');
            }
        });
    });

    // --- 6. INTERACTIVE MODAL CONTROLLER (CASE STUDIES) ---
    const openModalBtns = document.querySelectorAll('.open-modal');
    const closeModalBtns = document.querySelectorAll('.modal-close');
    const modalOverlays = document.querySelectorAll('.modal-overlay');

    const openModal = (modalId) => {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden'; // Stop background scrolling
        }
    };

    const closeModal = (modal) => {
        modal.classList.remove('active');
        document.body.style.overflow = ''; // Restore scroll
    };

    openModalBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetModalId = btn.getAttribute('data-modal');
            openModal(targetModalId);
        });
    });

    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const modal = btn.closest('.modal-overlay');
            closeModal(modal);
        });
    });

    modalOverlays.forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                closeModal(overlay);
            }
        });
    });

    // Close on Escape Key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const activeModal = document.querySelector('.modal-overlay.active');
            if (activeModal) {
                closeModal(activeModal);
            }
        }
    });

    // --- 7. MOCK CONTACT FORM INTERACTION ---
    const contactForm = document.getElementById('portfolio-contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const submitBtn = contactForm.querySelector('.submit-btn');
            const submitText = submitBtn.querySelector('span');
            const submitIcon = submitBtn.querySelector('i');
            
            // Trigger beautiful loading animation in submit button
            submitText.textContent = "Sending Message...";
            submitIcon.className = "fa-solid fa-circle-notch fa-spin";
            submitBtn.style.opacity = 0.8;
            submitBtn.disabled = true;

            setTimeout(() => {
                // Show completion feedback
                alert("Thank you for reaching out, Talari! This contact form demo is successfully simulated. Under actual deployment, this sends payloads directly to endpoints.");
                
                // Reset form state
                contactForm.reset();
                submitText.textContent = "Send Message";
                submitIcon.className = "fa-solid fa-paper-plane";
                submitBtn.style.opacity = 1;
                submitBtn.disabled = false;
            }, 1800);
        });
    }

    // --- 8. AWWWARDS-STYLE ANIMATED CUSTOM CURSOR ---
    const cursorDot = document.querySelector('.custom-cursor-dot');
    const cursorOutline = document.querySelector('.custom-cursor-outline');

    if (cursorDot && cursorOutline) {
        window.addEventListener('mousemove', (e) => {
            const posX = e.clientX;
            const posY = e.clientY;

            // Instant positioning for the solid dot
            cursorDot.style.left = `${posX}px`;
            cursorDot.style.top = `${posY}px`;

            // Smooth trailing positioning for the circular outline
            cursorOutline.style.left = `${posX}px`;
            cursorOutline.style.top = `${posY}px`;
        });

        // Dynamic scale-up on hovering interactive nodes
        const hoverables = document.querySelectorAll('a, button, .btn-text, .open-modal, .theme-btn, .mobile-menu-btn, .close-btn, input, textarea');
        hoverables.forEach(node => {
            node.addEventListener('mouseenter', () => {
                cursorDot.classList.add('hovered');
                cursorOutline.classList.add('hovered');
            });
            node.addEventListener('mouseleave', () => {
                cursorDot.classList.remove('hovered');
                cursorOutline.classList.remove('hovered');
            });
        });
    }

    // --- 9. HIGH-FIDELITY 3D TILT EFFECT ON CARDS ---
    const interactiveCards = document.querySelectorAll('.project-card, .skill-card, .timeline-card');
    
    interactiveCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            
            // Determine pivot point coordinates (center of card)
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            // Calculate rotational tilt angles (max 8 degrees tilt for premium feel)
            const tiltAngleX = ((centerY - mouseY) / centerY) * 8;
            const tiltAngleY = ((mouseX - centerX) / centerX) * 8;

            card.style.transform = `perspective(1000px) rotateX(${tiltAngleX}deg) rotateY(${tiltAngleY}deg) translateY(-8px)`;
        });

        card.addEventListener('mouseleave', () => {
            // Restore native transform states smoothly
            card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0)';
        });
    });

});
